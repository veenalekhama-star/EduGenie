"""
qna.py - Question & Answer Module
Handles student queries with conversational warmth, clarity, and pedagogical depth.
"""

import logging
from typing import Optional
from gemini_client import generate_ai_response, is_api_configured

logger = logging.getLogger("EduGenie.QnA")


def answer_question(question: str, subject_context: Optional[str] = None) -> str:
    """
    Answers academic, conceptual, or general knowledge questions.
    Adopts the persona of an encouraging, knowledgeable teacher who breaks
    down answers with relatable examples and clear logic.
    """
    cleaned_question = question.strip()
    if not cleaned_question:
        return "Please ask a question! I'm here to help you understand any concept."

    if not is_api_configured():
        return (
            "⚠️ API Key Required: Please add your Gemini API key in the `.env` file "
            "to start asking questions."
        )

    system_instruction = (
        "You are EduGenie, a friendly, encouraging, and articulate AI tutor. "
        "Your goal is to help learners truly understand concepts rather than just memorizing facts. "
        "Guidelines:\n"
        "1. Give a direct, crystal-clear answer in the opening paragraph.\n"
        "2. Break down the core mechanism or reasoning using simple terms and an intuitive analogy.\n"
        "3. Highlight key facts or bullet points for easy reading.\n"
        "4. Conclude with an insightful 'Why this matters' or a thought-provoking follow-up question.\n"
        "5. Maintain an engaging, approachable, and supportive tone throughout."
    )

    prompt = f"Student Question: {cleaned_question}"
    if subject_context:
        prompt = f"Subject / Context: {subject_context}\n" + prompt

    logger.info(f"Generating Q&A response for question: '{cleaned_question[:60]}...'")
    return generate_ai_response(
        prompt=prompt,
        system_instruction=system_instruction,
        temperature=0.7,
        max_output_tokens=1200
    )


# Alias for backwards compatibility with existing imports and routes
answer_question_with_gemini = answer_question
