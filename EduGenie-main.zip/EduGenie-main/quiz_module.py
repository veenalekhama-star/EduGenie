"""
quiz_module.py - Interactive Assessment & Quiz Generator
Creates thought-provoking multiple choice questions to assess conceptual mastery.
"""

import json
import logging
from typing import List, Dict, Any
from gemini_client import (
    generate_ai_response,
    extract_clean_json,
    is_api_configured,
    get_generative_model,
    format_human_friendly_error
)

logger = logging.getLogger("EduGenie.Quiz")


def clean_json_block(text: str) -> str:
    """
    Strips markdown code block markers (```json ... ```) from model output.
    Kept for backwards-compatibility.
    """
    import re
    cleaned = re.sub(r"```json\s*", "", text, flags=re.IGNORECASE)
    cleaned = re.sub(r"```\s*", "", cleaned)
    return cleaned.strip()


def generate_quiz(text: str, num_questions: int = 3) -> List[Dict[str, Any]]:
    """
    Generates high-quality multiple choice questions (MCQs) based on the provided passage or topic.
    Each question includes 4 plausible options, the verified correct answer, and an explanation.
    """
    cleaned_text = text.strip()
    if not cleaned_text:
        return [{"error": "Please provide some study material or a topic to generate a quiz from."}]

    if not is_api_configured():
        return [{"error": "GEMINI_API_KEY is not configured in .env. Please set your key to generate quizzes."}]

    system_instruction = (
        "You are an assessment specialist and university tutor. "
        f"Your task is to create exactly {num_questions} high-quality, conceptual multiple-choice questions "
        "based on the provided text. Focus on deep understanding rather than superficial recall.\n\n"
        "Rules:\n"
        "1. Each question must have exactly 4 distinct, plausible options.\n"
        "2. The correct answer MUST be an exact verbatim match to one of the 4 options.\n"
        "3. Provide a brief explanation for why the correct answer is right.\n"
        "4. Output MUST be a strictly valid JSON array of objects with keys: 'question', 'options', 'answer', 'explanation'."
    )

    prompt = f"""Generate {num_questions} multiple choice questions for this topic or text:

\"\"\"{cleaned_text}\"\"\"

Output format strictly as JSON:
[
  {{
    "question": "Clear and specific question text?",
    "options": ["Option A", "Option B", "Option C", "Option D"],
    "answer": "Option A",
    "explanation": "Brief reason why Option A is correct."
  }}
]
"""

    try:
        # Use lower temperature for deterministic adherence to facts and JSON format
        model = get_generative_model(temperature=0.3, max_output_tokens=1500)
        full_prompt = f"{system_instruction}\n\n{prompt}"
        response = model.generate_content(full_prompt)

        if not response or not response.text:
            return [{"error": "Unable to generate quiz questions. Please try a longer text snippet."}]

        raw_content = response.text.strip()
        parsed_data = extract_clean_json(raw_content)

        # Normalize data into a flat list of questions
        if isinstance(parsed_data, dict):
            if "quiz" in parsed_data and isinstance(parsed_data["quiz"], list):
                parsed_data = parsed_data["quiz"]
            elif "questions" in parsed_data and isinstance(parsed_data["questions"], list):
                parsed_data = parsed_data["questions"]
            else:
                parsed_data = [parsed_data]

        # Sanity check each question object
        validated_quiz: List[Dict[str, Any]] = []
        for idx, item in enumerate(parsed_data):
            if not isinstance(item, dict):
                continue
            question = item.get("question", f"Question {idx+1}")
            options = item.get("options", [])
            answer = item.get("answer", "")
            explanation = item.get("explanation", "")

            # Ensure we have options list
            if not isinstance(options, list) or len(options) == 0:
                continue

            # Ensure answer matches one of the options
            if answer not in options and len(options) > 0:
                # Attempt case-insensitive match
                matched = next((opt for opt in options if opt.strip().lower() == answer.strip().lower()), None)
                if matched:
                    answer = matched
                else:
                    options.append(answer)

            validated_quiz.append({
                "question": question,
                "options": options,
                "answer": answer,
                "explanation": explanation
            })

        if not validated_quiz:
            return [{"error": "Could not extract valid question format. Please try again with more detailed text."}]

        logger.info(f"Successfully generated {len(validated_quiz)} quiz questions.")
        return validated_quiz

    except json.JSONDecodeError as jde:
        logger.error(f"Quiz JSON parsing error: {jde}")
        return [{"error": "The model returned a response that couldn't be parsed into quiz format. Please retry."}]
    except Exception as exc:
        logger.error(f"Quiz generation error: {exc}", exc_info=False)
        return [{"error": format_human_friendly_error(exc)}]
