"""
main.py - EduGenie FastAPI Application
High-performance ASGI backend connecting students to intelligent AI tutoring modules.
"""

import os
import asyncio
import logging
from contextlib import asynccontextmanager
from typing import Optional, List, Dict, Any

from fastapi import FastAPI, Request, Query, Form, HTTPException, status
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel, Field

# Core EduGenie AI Services
from gemini_client import (
    is_api_configured,
    get_active_model_name,
    DEFAULT_MODEL
)
from qna import answer_question
from explanation_module import explain_topic
from quiz_module import generate_quiz
from summary_module import summarize_text
from learning_path import get_learning_recommendations

# Set up logging
logger = logging.getLogger("EduGenie.Server")


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Handles application startup and shutdown events cleanly."""
    logger.info("🚀 Starting EduGenie Learning Assistant server...")
    if is_api_configured():
        logger.info(f"Gemini AI configured successfully using model: {get_active_model_name()}")
    else:
        logger.warning("Gemini API key not found in .env. Some AI features will require configuration.")
    yield
    logger.info("🛑 Shutting down EduGenie server...")


app = FastAPI(
    title="EduGenie: AI-Powered Learning Assistant",
    description="Interactive educational workspace powered by Google Gemini generative models.",
    version="1.2.0",
    lifespan=lifespan
)

# Ensure required assets directories exist
os.makedirs("static", exist_ok=True)
os.makedirs("templates", exist_ok=True)

app.mount("/static", StaticFiles(directory="static"), name="static")
templates = Jinja2Templates(directory="templates")


# ---------------------------------------------------------------------------
# Request Schemas
# ---------------------------------------------------------------------------
class QuestionPayload(BaseModel):
    question: str = Field(..., min_length=1, description="The student's question or problem statement.")
    context: Optional[str] = Field(None, description="Optional subject or background context.")


class TopicPayload(BaseModel):
    topic: str = Field(..., min_length=1, description="The concept or topic to be explained or mapped.")
    audience: Optional[str] = Field("High School", description="Target audience comprehension level.")
    tone: Optional[str] = Field("Balanced", description="Tone and depth of the response.")


class TextPayload(BaseModel):
    text: str = Field(..., min_length=1, description="The source reading material or text passage.")
    num_questions: Optional[int] = Field(3, ge=1, le=10, description="Number of questions to generate for quiz.")


class SettingsPayload(BaseModel):
    model: Optional[str] = Field(None, description="Gemini model identifier.")
    audience: Optional[str] = Field(None, description="Preferred default learner level.")
    tone: Optional[str] = Field(None, description="Preferred default tone.")


# ---------------------------------------------------------------------------
# Web UI & System Status Endpoints
# ---------------------------------------------------------------------------
@app.get("/", response_class=HTMLResponse)
async def serve_home_ui(request: Request):
    """
    Renders the EduGenie interactive single-page application.
    """
    return templates.TemplateResponse(
        request=request,
        name="index.html",
        context={"has_api_key": is_api_configured()}
    )


@app.get("/api/status")
async def get_system_status():
    """
    Returns the current health and AI configuration status.
    """
    return {
        "status": "online",
        "gemini_configured": is_api_configured(),
        "model": get_active_model_name()
    }


@app.get("/api/settings")
async def get_current_settings():
    """
    Returns available models, active model, and engine configuration.
    """
    return {
        "gemini_configured": is_api_configured(),
        "active_model": get_active_model_name(),
        "available_models": [
            {
                "id": "models/gemini-3.5-flash-lite",
                "name": "Gemini 3.5 Flash-Lite",
                "desc": "Ultra-fast ~1.5s latency, high throughput, and high reliability for real-time tutoring.",
                "tag": "Fastest (Recommended)"
            },
            {
                "id": "models/gemini-3.8-flash",
                "name": "Gemini 3.8 Flash",
                "desc": "Advanced reasoning & deep explanations for complex academic questions.",
                "tag": "High Accuracy"
            },
            {
                "id": "models/gemini-3.7-flash",
                "name": "Gemini 3.7 Flash",
                "desc": "Balanced hybrid reasoning for mathematical problem-solving.",
                "tag": "Hybrid"
            },
            {
                "id": "local_lamini",
                "name": "LaMini-Flan-T5-783M",
                "desc": "Local HuggingFace model running on your machine for offline privacy.",
                "tag": "Offline Fallback"
            }
        ]
    }


@app.post("/api/settings")
async def update_settings(payload: SettingsPayload):
    """
    Updates the active model or preference settings for the current session.
    """
    if payload.model:
        os.environ["GEMINI_MODEL"] = payload.model
        logger.info(f"Updated active Gemini model to: {payload.model}")

    return {
        "success": True,
        "active_model": get_active_model_name(),
        "audience": payload.audience or "General",
        "tone": payload.tone or "Balanced"
    }


# ---------------------------------------------------------------------------
# Module 1: Q&A Endpoint
# ---------------------------------------------------------------------------
@app.get("/qa")
async def qna_get_handler(question: str = Query(..., description="Student question")):
    """Handles GET requests for quick question answering."""
    if not question.strip():
        return JSONResponse(
            status_code=status.HTTP_400_BAD_REQUEST,
            content={"error": "Please provide a valid question."}
        )
    answer = await asyncio.to_thread(answer_question, question)
    return {"question": question, "answer": answer}


@app.post("/qa")
async def qna_post_handler(request: Request):
    """Handles POST requests for question answering (JSON or Form)."""
    question = ""
    try:
        body = await request.json()
        question = body.get("question", "")
    except Exception:
        form = await request.form()
        question = str(form.get("question", ""))

    if not question.strip():
        return JSONResponse(
            status_code=status.HTTP_400_BAD_REQUEST,
            content={"error": "Please provide a valid question."}
        )

    answer = await asyncio.to_thread(answer_question, question)
    return {"question": question, "answer": answer}


# ---------------------------------------------------------------------------
# Module 2: Concept Explainer Endpoint
# ---------------------------------------------------------------------------
@app.post("/explain")
async def explain_handler(request: Request):
    """Breaks down a topic or concept into structured, intuitive lessons."""
    topic = ""
    audience = "High School"
    tone = "Balanced"

    try:
        data = await request.json()
        topic = data.get("topic", "")
        audience = data.get("audience", audience)
        tone = data.get("tone", tone)
    except Exception:
        form = await request.form()
        topic = str(form.get("topic", ""))

    if not topic.strip():
        return JSONResponse(
            status_code=status.HTTP_400_BAD_REQUEST,
            content={"error": "Please provide a topic to explain."}
        )

    explanation = await asyncio.to_thread(explain_topic, topic, audience, tone)
    return {"topic": topic, "explanation": explanation}


# ---------------------------------------------------------------------------
# Module 3: Assessment & Quiz Endpoint
# ---------------------------------------------------------------------------
@app.post("/quiz")
async def quiz_handler(request: Request):
    """Generates multiple choice questions with answers and explanations."""
    text = ""
    try:
        data = await request.json()
        text = data.get("text", "")
    except Exception:
        form = await request.form()
        text = str(form.get("text", ""))

    if not text.strip():
        return JSONResponse(
            status_code=status.HTTP_400_BAD_REQUEST,
            content={"error": "Please provide text or a topic to generate quiz questions from."}
        )

    quiz = await asyncio.to_thread(generate_quiz, text)
    return {"quiz": quiz}


# ---------------------------------------------------------------------------
# Module 4: Study Summarizer Endpoint
# ---------------------------------------------------------------------------
@app.post("/summarize")
async def summarize_handler(request: Request):
    """Condenses text into high-yield takeaways and essential definitions."""
    text = ""
    try:
        data = await request.json()
        text = data.get("text", "")
    except Exception:
        form = await request.form()
        text = str(form.get("text", ""))

    if not text.strip():
        return JSONResponse(
            status_code=status.HTTP_400_BAD_REQUEST,
            content={"error": "Please provide the text you would like summarized."}
        )

    summary = await asyncio.to_thread(summarize_text, text)
    return {"summary": summary}


# ---------------------------------------------------------------------------
# Module 5: Personalized Learning Roadmap Endpoint
# ---------------------------------------------------------------------------
@app.get("/learn/recommendations")
async def learning_path_get_handler(topic: str = Query(..., description="Skill or subject to learn")):
    """Handles GET requests for generating a learning path roadmap."""
    if not topic.strip():
        return JSONResponse(
            status_code=status.HTTP_400_BAD_REQUEST,
            content={"error": "Please provide a valid topic for your learning roadmap."}
        )

    recommendation = await asyncio.to_thread(get_learning_recommendations, topic)
    return {"topic": topic, "recommendation": recommendation}


@app.post("/learn/recommendations")
async def learning_path_post_handler(request: Request):
    """Handles POST requests for generating a learning path roadmap."""
    topic = ""
    try:
        data = await request.json()
        topic = data.get("topic", "")
    except Exception:
        form = await request.form()
        topic = str(form.get("topic", ""))

    if not topic.strip():
        return JSONResponse(
            status_code=status.HTTP_400_BAD_REQUEST,
            content={"error": "Please provide a valid topic for your learning roadmap."}
        )

    recommendation = await asyncio.to_thread(get_learning_recommendations, topic)
    return {"topic": topic, "recommendation": recommendation}


# ---------------------------------------------------------------------------
# Local Development Runner
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    import uvicorn
    port = int(os.getenv("PORT", "8000"))
    logger.info(f"Starting EduGenie on http://127.0.0.1:{port}")
    uvicorn.run("main:app", host="127.0.0.1", port=port, reload=True)
