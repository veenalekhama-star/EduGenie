import os
import re
import json
import logging
import warnings
from typing import Optional, Any, Dict

# Suppress noisy library-level deprecation warnings to keep logs clean and readable
warnings.filterwarnings("ignore", category=FutureWarning)

import google.generativeai as genai
from dotenv import load_dotenv

# Set up clean, structured logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    datefmt="%H:%M:%S"
)
logger = logging.getLogger("EduGenie.AI")

# Default model configuration (Gemini 3.5 Flash-Lite has proven fastest ~1.5s latency)
DEFAULT_MODEL = "models/gemini-3.5-flash-lite"
FALLBACK_KEY_PLACEHOLDER = "your_gemini_api_key_here"

# Cache active model instance to avoid re-instantiating on every request
_cached_model_name: Optional[str] = None
_cached_generative_model: Optional[genai.GenerativeModel] = None


def get_api_key() -> str:
    """
    Retrieves the Gemini API key from environment variables.
    Reloads .env to pick up any runtime changes made by the user.
    """
    load_dotenv(override=True)
    return os.getenv("GEMINI_API_KEY", "").strip()


def is_api_configured() -> bool:
    """
    Checks if a valid, non-placeholder API key is available in the environment.
    """
    key = get_api_key()
    return bool(key and key != FALLBACK_KEY_PLACEHOLDER)


def get_active_model_name() -> str:
    """
    Gets the currently selected model name from the environment or falls back to default.
    """
    load_dotenv(override=True)
    return os.getenv("GEMINI_MODEL", DEFAULT_MODEL).strip()


def get_generative_model(
    model_name: Optional[str] = None,
    temperature: float = 0.7,
    max_output_tokens: int = 1500
) -> genai.GenerativeModel:
    """
    Returns a configured Gemini GenerativeModel instance.
    Reuses the cached model if the name and settings match.
    """
    global _cached_model_name, _cached_generative_model

    api_key = get_api_key()
    if not api_key or api_key == FALLBACK_KEY_PLACEHOLDER:
        raise ValueError(
            "Gemini API key is not configured. Please add your GEMINI_API_KEY to the .env file."
        )

    # Configure the Google Generative AI client
    genai.configure(api_key=api_key)

    selected_model = model_name or get_active_model_name()

    # Re-instantiate if model changed or not yet initialized
    if _cached_generative_model is None or _cached_model_name != selected_model:
        logger.info(f"Initializing Gemini model: {selected_model}")
        _cached_model_name = selected_model
        _cached_generative_model = genai.GenerativeModel(
            model_name=selected_model,
            generation_config={
                "temperature": temperature,
                "max_output_tokens": max_output_tokens,
            }
        )

    return _cached_generative_model


def format_human_friendly_error(exc: Exception) -> str:
    """
    Translates raw API errors into clear, friendly, actionable advice for users.
    """
    msg = str(exc)
    if "429" in msg or "quota" in msg.lower() or "resourceexhausted" in msg.lower():
        return (
            "⏳ **Rate limit reached**: The Gemini API quota limit was temporarily reached. "
            "Please wait a few moments before trying again, or select another model from Settings."
        )
    if "401" in msg or "API_KEY_INVALID" in msg or "api key not valid" in msg.lower():
        return (
            "🔑 **Invalid API Key**: Your Gemini API key could not be verified. "
            "Please check the `GEMINI_API_KEY` in your `.env` file."
        )
    if "503" in msg or "unavailable" in msg.lower():
        return (
            "🌐 **Service Busy**: Google Gemini servers are experiencing temporary high load. "
            "Please retry your request in a few seconds."
        )
    return (
        f"⚠️ **Unable to complete request**: {msg}. "
        "Please check your internet connection and settings."
    )


def generate_ai_response(
    prompt: str,
    system_instruction: Optional[str] = None,
    temperature: float = 0.7,
    max_output_tokens: int = 1500
) -> str:
    """
    Helper function to send a prompt to Gemini and return the cleaned text response.
    Includes human-friendly error messages if anything goes wrong.
    """
    if not is_api_configured():
        return (
            "⚠️ API Key Missing: Please add your Gemini API key in the `.env` file "
            "(GEMINI_API_KEY=your_key_here) to enable AI responses."
        )

    try:
        model = get_generative_model(
            temperature=temperature,
            max_output_tokens=max_output_tokens
        )
        
        full_prompt = f"{system_instruction}\n\n{prompt}" if system_instruction else prompt
        response = model.generate_content(full_prompt)

        if hasattr(response, "text") and response.text:
            return response.text.strip()
        elif hasattr(response, "parts") and response.parts:
            return "".join(part.text for part in response.parts if hasattr(part, "text")).strip()
        
        return "I couldn't generate a response for that request. Please try rephrasing your prompt."

    except Exception as exc:
        logger.error(f"Gemini API call failed: {exc}", exc_info=False)
        return format_human_friendly_error(exc)


def extract_clean_json(raw_text: str) -> Any:
    """
    Robustly parses JSON from LLM responses, stripping out markdown code fences
    (e.g., ```json ... ```) or conversational preamble if present.
    """
    text = raw_text.strip()
    
    # Strip markdown code blocks if the model enclosed the JSON
    text = re.sub(r"^```(?:json)?\s*", "", text, flags=re.IGNORECASE | re.MULTILINE)
    text = re.sub(r"```\s*$", "", text, flags=re.MULTILINE)
    text = text.strip()

    # Try direct parse first
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        pass

    # If direct parse fails, find first '[' or '{' to the matching closing bracket
    match = re.search(r"(\[.*\]|\{.*\})", text, re.DOTALL)
    if match:
        try:
            return json.loads(match.group(1))
        except json.JSONDecodeError as err:
            logger.warning(f"Failed to decode regex-extracted JSON: {err}")

    raise ValueError(f"Could not extract valid JSON from response: {text[:120]}...")
