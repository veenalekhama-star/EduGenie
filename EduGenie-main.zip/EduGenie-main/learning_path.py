"""
learning_path.py - Personalized Learning Roadmap Module
Designs structured, goal-oriented learning roadmaps with realistic milestones and hands-on projects.
"""

import logging
from typing import Optional
from gemini_client import generate_ai_response, is_api_configured

logger = logging.getLogger("EduGenie.Roadmap")


def get_learning_recommendations(
    topic: str,
    target_timeline: Optional[str] = None
) -> str:
    """
    Constructs an end-to-end learning roadmap for any technical or academic domain.
    Includes prerequisites, staged difficulty phases, milestone projects, and curated resources.
    """
    cleaned_topic = topic.strip()
    if not cleaned_topic:
        return "Please specify a subject, technology, or skill you want to learn!"

    if not is_api_configured():
        return (
            "⚠️ API Key Required: Please configure `GEMINI_API_KEY` in your `.env` file "
            "to generate personalized learning roadmaps."
        )

    system_instruction = (
        "You are an inspiring engineering and academic mentor who specializes in designing "
        "effective, project-based self-study curriculums.\n\n"
        "Generate a pragmatic, motivating, and beautifully formatted Markdown roadmap with these sections:\n"
        "### 🎯 Learning Objectives & Prerequisites\n"
        "- What you will be able to build/do upon completion.\n"
        "- Core foundational prerequisites (if any).\n\n"
        "### 🧱 Phase 1: Foundations & Core Fundamentals (Weeks 1–2)\n"
        "- Key concepts to master first.\n"
        "- **Hands-On Starter Task**: A 1-hour micro-project to cement initial understanding.\n\n"
        "### ⚙️ Phase 2: Practical Application & Real Tooling (Weeks 3–5)\n"
        "- Industry-standard frameworks, libraries, or methodologies.\n"
        "- **Milestone Project**: A realistic intermediate challenge with concrete deliverables.\n\n"
        "### 🚀 Phase 3: Advanced Mastery & Architecture (Weeks 6+)\n"
        "- Edge cases, optimization, design patterns, and scaling.\n"
        "- **Capstone Portfolio Project**: A standout project worthy of a resume or GitHub showcase.\n\n"
        "### 📚 Recommended High-Quality Resources\n"
        "- Free official documentation, courses, and interactive practice platforms.\n\n"
        "### 🛡️ Mentor Pro-Tips (How to Avoid Common Traps)\n"
        "- 2-3 pieces of actionable advice to prevent tutorial hell and accelerate real retention."
    )

    prompt = f"Please design a comprehensive learning roadmap for: '{cleaned_topic}'."
    if target_timeline:
        prompt += f" Desired timeframe: {target_timeline}."

    logger.info(f"Generating learning roadmap for topic: '{cleaned_topic}'")
    return generate_ai_response(
        prompt=prompt,
        system_instruction=system_instruction,
        temperature=0.7,
        max_output_tokens=1600
    )
