"""
summary_module.py - Smart Study Summarization Module
Condenses complex texts, articles, or chapters into high-yield, structured revision summaries.
"""

import logging
from typing import Optional
from gemini_client import generate_ai_response, is_api_configured

logger = logging.getLogger("EduGenie.Summarizer")


def summarize_text(text: str, summary_style: str = "Comprehensive") -> str:
    """
    Distills long-form reading passages into actionable, well-organized study notes.
    Extracts core thesis, bulleted takeaways, and critical terminology.
    """
    cleaned_text = text.strip()
    if not cleaned_text:
        return "Please paste or type the text you would like to summarize."

    if not is_api_configured():
        return (
            "⚠️ API Key Required: Please configure your `GEMINI_API_KEY` in `.env` "
            "to generate smart summaries."
        )

    system_instruction = (
        "You are an expert academic research assistant and speed-reading coach. "
        "Your mission is to summarize study material so that a student can review it in 60 seconds "
        "and grasp all essential points with total clarity.\n\n"
        "Format your summary in clean Markdown using these sections:\n"
        "### 📌 Executive Summary\n"
        "A crisp, 2-3 sentence synopsis highlighting the core message and significance.\n\n"
        "### 🔑 Key Takeaways & Mechanisms\n"
        "3 to 5 clear, high-yield bullet points. Bold key terms for effortless scanning.\n\n"
        "### 📖 Essential Vocabulary & Definitions\n"
        "Definitions for 2-4 critical terms or jargon introduced in the passage (if applicable).\n\n"
        "### 💡 Why It Matters / Practical Application\n"
        "1-2 sentences on why this knowledge is relevant or how it connects to broader concepts."
    )

    prompt = f"Please summarize the following text:\n\n\"\"\"{cleaned_text}\"\"\""

    logger.info(f"Summarizing text passage ({len(cleaned_text)} characters)...")
    return generate_ai_response(
        prompt=prompt,
        system_instruction=system_instruction,
        temperature=0.5,
        max_output_tokens=1400
    )
