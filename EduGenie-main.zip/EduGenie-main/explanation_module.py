"""
explanation_module.py - Concept Explainer Module
Deconstructs complex academic or technical topics into intuitive, relatable lessons.
"""

import logging
from typing import Optional
from gemini_client import generate_ai_response, is_api_configured

logger = logging.getLogger("EduGenie.Explainer")


def explain_topic(
    topic: str,
    target_audience: str = "High School",
    tone: str = "Balanced"
) -> str:
    """
    Transforms challenging concepts into clear, engaging, and memorable explanations.
    Uses real-world analogies, first-principles thinking, and structured milestones.
    """
    cleaned_topic = topic.strip()
    if not cleaned_topic:
        return "Please enter a topic or concept you'd like me to explain!"

    if not is_api_configured():
        return (
            "⚠️ API Key Required: Please configure your `GEMINI_API_KEY` in the `.env` file "
            "to unlock detailed concept breakdowns."
        )

    system_instruction = (
        "You are an inspiring educator renowned for making any complex topic intuitively clear. "
        f"Tailor your explanation for a {target_audience} audience using a {tone.lower()} tone.\n\n"
        "Structure your explanation with the following clear markdown sections:\n"
        "### 🌟 The Big Picture (In Plain English)\n"
        "A 2-3 sentence elevator pitch that explains what this is and why anyone should care.\n\n"
        "### 💡 The Relatable Analogy\n"
        "A memorable, real-world metaphor that gives the learner an instant 'Aha!' moment.\n\n"
        "### ⚙️ How It Works (Step by Step)\n"
        "Clear, logically progressive breakdown of the underlying principles or mechanism.\n\n"
        "### 🚫 Common Pitfalls & Misconceptions\n"
        "1-2 common misunderstandings learners often have, and how to think about them correctly.\n\n"
        "### 🚀 Where You See This in the Real World\n"
        "Practical applications or cutting-edge examples that make the concept come alive."
    )

    prompt = f"Please explain the topic: '{cleaned_topic}'"

    logger.info(f"Generating concept explanation for: '{cleaned_topic}' (Audience: {target_audience})")
    return generate_ai_response(
        prompt=prompt,
        system_instruction=system_instruction,
        temperature=0.7,
        max_output_tokens=1500
    )
