# EduGenie: AI-Powered Learning Assistant 🎓✨

> **An intelligent, full-stack educational workspace built with FastAPI, Google Gemini AI, and a modern tactile interface.**

---

## 📌 Project Overview

**EduGenie** is a student-focused learning assistant designed to deconstruct complex topics, answer academic doubts, generate interactive self-assessments, summarize study materials, and construct step-by-step learning roadmaps.

---

## 🚀 Core Modules

1. **Ask EduGenie (Q&A)** (`/qa`): Direct problem-solving with grounded reasoning, relatable real-world analogies, and takeaways.
2. **Concept Explainer** (`/explain`): First-principles breakdowns that simplify technical topics without unnecessary jargon.
3. **Smart Summarizer** (`/summarize`): Distills textbook chapters, research papers, and study passages into executive takeaways and key definitions.
4. **Assessment & Quiz Generator** (`/quiz`): Generates 3 conceptual MCQs with automated validation and instant feedback.
5. **Learning Roadmap Builder** (`/learn/recommendations`): Creates milestone-based study pathways with estimated timeframes and hands-on capstone projects.

---

## 🛠️ Architecture & Tech Stack

- **Backend**: Python 3.10+, FastAPI, Uvicorn, Pydantic V2
- **AI Inference**: Google Gemini API (`gemini-3.5-flash-lite`, `gemini-3.8-flash`) via `google-generativeai`
- **Frontend**: Responsive Single-Page Application (HTML5, Vanilla CSS, Jinja2, Lucide Icons, Marked.js)

```mermaid
flowchart LR
    A[Student / Browser] -->|HTTP / JSON| B[FastAPI Backend - main.py]
    B --> C[EduGenie AI Core - gemini_client.py]
    C -->|API Request| D[Google Gemini 3.5 Flash-Lite]
    D -->|Structured Response| C
    C --> B
    B -->|Markdown / JSON| A
```

---

## 📂 Project Structure

```text
├── main.py                  # FastAPI server, endpoints & lifecycle management
├── gemini_client.py         # Centralized Gemini AI client & JSON parser
├── qna.py                   # Tutor Q&A module
├── explanation_module.py    # Concept explainer module
├── summary_module.py        # Study summarization module
├── quiz_module.py           # MCQ generator & validator
├── learning_path.py         # Milestone learning roadmap builder
├── requirements.txt         # Project dependencies
├── .env.example             # Environment template
├── .env                     # Local API keys (git-ignored)
├── templates/
│   └── index.html           # Modern interactive single-page interface
└── static/
    └── style.css            # Tactile neumorphic design system
```

---

## ⚡ Quickstart Guide (3 Simple Steps)

### Step 1: Clone & Configure API Key
```bash
git clone https://github.com/your-username/your-repo.git
cd python-LLM
```

Copy `.env.example` to `.env` and insert your free Gemini API key:
```env
GEMINI_API_KEY=your_actual_gemini_api_key_here
GEMINI_MODEL=models/gemini-3.5-flash-lite
```
*(Get a free key from [Google AI Studio](https://aistudio.google.com/app/apikey))*

### Step 2: Install Dependencies
```bash
pip install -r requirements.txt
```

### Step 3: Run the Application
```bash
python main.py
```
Open your browser at: **[http://127.0.0.1:8000](http://127.0.0.1:8000)**

---

## 📡 API Reference

| Endpoint | Method | Description | Sample Payload / Query |
| :--- | :---: | :--- | :--- |
| `/` | `GET` | Main Interactive Web UI | - |
| `/qa` | `GET` / `POST` | Academic Q&A | `?question=Why is the sky blue?` |
| `/explain` | `POST` | Concept Explainer | `{"topic": "Quantum Computing"}` |
| `/summarize` | `POST` | Text Summarization | `{"text": "Photosynthesis is the process..."}` |
| `/quiz` | `POST` | MCQ Assessment | `{"text": "The Pythagorean Theorem..."}` |
| `/learn/recommendations` | `GET` / `POST` | Learning Roadmap | `?topic=SQL & Database Design` |
| `/api/status` | `GET` | System Health Check | - |
| `/api/settings` | `GET` / `POST` | Model Configuration | `{"model": "models/gemini-3.5-flash-lite"}` |
